Static assets can be placed here if the UI is expanded.
